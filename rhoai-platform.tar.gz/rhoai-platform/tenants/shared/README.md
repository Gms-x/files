# Shared CR

GitOps manifests for hosting shared resources (such as `LLMInferenceServiceConfig`) in cluster-level or shared Data Science platform namespaces.

## Layout

```text
tenants/shared/llm-inferenceservice-config/
├── kustomization.yaml
└── llm-inference-config.yaml