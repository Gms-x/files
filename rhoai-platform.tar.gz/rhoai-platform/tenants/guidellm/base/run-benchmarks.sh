#!/bin/sh
# Runs the full guidellm scenario suite against one model endpoint.
#
# Model specifics arrive as environment variables so this script is shared by
# every per-model CronJob. Kustomize packages it via configMapGenerator, so it
# lives here as a real shell file rather than embedded YAML.
#
# Required env: MODEL_SLUG TARGET MODEL_NAME TOKENIZER
# Optional env: HTTP2 REQUEST_FORMAT USE_SA_TOKEN SEED

# Deliberately NOT `set -e`: a failing scenario must not abort the rest.
set -u

: "${MODEL_SLUG:?MODEL_SLUG is required}"
: "${TARGET:?TARGET is required}"
: "${MODEL_NAME:?MODEL_NAME is required}"
: "${TOKENIZER:?TOKENIZER is required}"

HTTP2="${HTTP2:-true}"
REQUEST_FORMAT="${REQUEST_FORMAT:-}"
USE_SA_TOKEN="${USE_SA_TOKEN:-true}"
SEED="${SEED:-42}"

TS="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="/results/${MODEL_SLUG}/${TS}"
mkdir -p "$OUT" || exit 1
SUMMARY="${OUT}/_summary.txt"

log() { echo "[$(date -u +%H:%M:%S)] $*" | tee -a "$SUMMARY"; }

log "model_slug = ${MODEL_SLUG}"
log "target     = ${TARGET}"
log "model_name = ${MODEL_NAME}"
log "tokenizer  = ${TOKENIZER}"
log "output     = ${OUT}"

# ---- proxy bypass ----------------------------------------------------------
# Narrow NO_PROXY to in-cluster suffixes for the duration of the run, matching
# the baseline CronJob. The broad list from the ConfigMap covers corporate
# ranges; this guarantees model traffic never goes near the proxy.
NO_PROXY=".svc,.svc.cluster.local,.cluster.local,localhost,127.0.0.1"
no_proxy="$NO_PROXY"
export NO_PROXY no_proxy

# ---- auth ------------------------------------------------------------------
SA_TOKEN_PATH=/var/run/secrets/kubernetes.io/serviceaccount/token
AUTH_FRAGMENT=""
CURL_AUTH=""
OPENAI_API_KEY=""
if [ "$USE_SA_TOKEN" = "true" ] && [ -r "$SA_TOKEN_PATH" ]; then
  OPENAI_API_KEY="$(cat "$SA_TOKEN_PATH")"
  export OPENAI_API_KEY
  AUTH_FRAGMENT=",api_key=${OPENAI_API_KEY}"
  CURL_AUTH="-H Authorization:Bearer ${OPENAI_API_KEY}"
  log "auth       = service account token"
else
  log "auth       = none"
fi

# ---- preflight: reachability + context window ------------------------------
MODELS_JSON="$(curl -sk --max-time 30 $CURL_AUTH "${TARGET}/v1/models" 2>/dev/null)"
if [ -z "$MODELS_JSON" ]; then
  log "FATAL: ${TARGET}/v1/models unreachable - is the model deployed?"
  exit 1
fi

MAX_LEN="$(printf '%s' "$MODELS_JSON" | python3 -c 'import json,sys; d=json.load(sys.stdin); print(int((d.get("data") or [{}])[0].get("max_model_len") or 0))' 2>/dev/null || echo 0)"
SERVED="$(printf '%s' "$MODELS_JSON" | python3 -c 'import json,sys; print(",".join(m.get("id","") for m in (json.load(sys.stdin).get("data") or [])))' 2>/dev/null || echo "")"

log "served ids = ${SERVED}"
log "max_model_len = ${MAX_LEN}"

# If the preflight could not be parsed, say so loudly. A zero here means the
# context guard below is inert and long-context scenarios will run unchecked --
# guidellm exits 0 even when every request errored, so a silent fail-open
# produces results that look fine and are not.
if [ "$MAX_LEN" -eq 0 ] || [ -z "$SERVED" ]; then
  log "!! PREFLIGHT PARSE FAILED - context guard is DISABLED for this run"
  log "!! raw /v1/models response (first 300 bytes):"
  printf '%s' "$MODELS_JSON" | head -c 300 | tee -a "$SUMMARY"
  echo "" | tee -a "$SUMMARY"
  if ! command -v python3 >/dev/null 2>&1; then
    log "!! cause: python3 is NOT on PATH in this image"
  fi
  log "!! long-context results from this run must be checked for errored requests"
fi

case ",${SERVED}," in
  *",${MODEL_NAME},"*) : ;;
  *) log "WARNING: MODEL_NAME '${MODEL_NAME}' not in served ids - expect 404s" ;;
esac

BACKEND="kind=openai_http,target=${TARGET},model=${MODEL_NAME}${AUTH_FRAGMENT},verify=false,validate_backend=false,http2=${HTTP2},follow_redirects=true,stream=true"
if [ -n "$REQUEST_FORMAT" ]; then
  BACKEND="${BACKEND},request_format=${REQUEST_FORMAT}"
fi

PASS=0; FAIL=0; SKIP=0

# run <name> <needed_ctx> <profile> <data> <extra_constraint_or_-> <duration>
run() {
  name="$1"; need="$2"; profile="$3"; data="$4"; extra="$5"; dur="$6"

  if [ "$MAX_LEN" -gt 0 ] && [ "$need" -gt "$MAX_LEN" ]; then
    log "SKIP ${name}: needs ${need} ctx, server max_model_len is ${MAX_LEN}"
    SKIP=$((SKIP+1))
    return
  fi

  log "RUN  ${name} (needs ${need} ctx)"
  set -- \
    --backend "$BACKEND" \
    --tokenizer "kind=huggingface_auto,model=${TOKENIZER}" \
    --profile "$profile" \
    --data "$data" \
    --constraint "kind=max_duration,seconds=${dur}" \
    --seed "kind=static,value=${SEED}" \
    --output "kind=json,path=${OUT}/${name}.json" \
    --output "kind=csv,path=${OUT}/${name}.csv" \
    --output "kind=html,path=${OUT}/${name}.html" \
    --disable-console-interactive
  if [ "$extra" != "-" ]; then
    set -- "$@" --constraint "$extra"
  fi
  if [ "$name" = "poisson" ]; then
    set -- "$@" --override profile.rate 0.3,0.5
  fi

  if guidellm run "$@" >>"${OUT}/${name}.log" 2>&1; then
    log "PASS ${name}"
    PASS=$((PASS+1))
  else
    log "FAIL ${name} (see ${name}.log)"
    FAIL=$((FAIL+1))
  fi
}

# ---- scenarios -------------------------------------------------------------
# "needed ctx" = prompt_tokens_max + output_tokens_max.
# Sized for servers at --max-model-len 16384. See README for the coverage table.

run chatbot 512 \
  'kind=sweep,sweep_size=8' \
  'kind=synthetic_text,prompt_tokens=128,prompt_tokens_min=64,prompt_tokens_max=256,output_tokens=128,output_tokens_min=64,output_tokens_max=256' \
  '-' 75

# Long-context. Centred at 12K so it fits a 16384 server (15360+512=15872).
# At --max-model-len 32768 restore the original 16K spread:
#   run rag-16k 25088 'kind=sweep,sweep_size=5' \
#     'kind=synthetic_text,prompt_tokens=16384,prompt_tokens_min=8192,prompt_tokens_max=24576,output_tokens=256,output_tokens_min=64,output_tokens_max=512' \
#     '-' 90
run rag-12k 15872 \
  'kind=sweep,sweep_size=5' \
  'kind=synthetic_text,prompt_tokens=12288,prompt_tokens_min=8192,prompt_tokens_max=15360,output_tokens=256,output_tokens_min=64,output_tokens_max=512' \
  '-' 90

run rag-4k 8704 \
  'kind=sweep,sweep_size=6' \
  'kind=synthetic_text,prompt_tokens=4096,prompt_tokens_min=2048,prompt_tokens_max=8192,output_tokens=256,output_tokens_min=64,output_tokens_max=512' \
  '-' 90

run codegen 2560 \
  'kind=sweep,sweep_size=6' \
  'kind=synthetic_text,prompt_tokens=256,prompt_tokens_min=64,prompt_tokens_max=512,output_tokens=1024,output_tokens_min=512,output_tokens_max=2048' \
  '-' 90

run poisson 2048 \
  'kind=poisson' \
  'kind=synthetic_text,prompt_tokens=512,prompt_tokens_min=128,prompt_tokens_max=1024,output_tokens=256,output_tokens_min=64,output_tokens_max=1024' \
  '-' 300

run saturation 2048 \
  'kind=sweep,sweep_size=8' \
  'kind=synthetic_text,prompt_tokens=512,prompt_tokens_min=128,prompt_tokens_max=1024,output_tokens=256,output_tokens_min=64,output_tokens_max=1024' \
  'kind=over_saturation,min_seconds=20,mode=enforce' 75

# ---- done ------------------------------------------------------------------
log "complete: ${PASS} passed, ${FAIL} failed, ${SKIP} skipped"
ln -sfn "$TS" "/results/${MODEL_SLUG}/latest" 2>/dev/null || true

# Non-zero only if everything failed - partial results are still useful.
[ "$PASS" -gt 0 ] || exit 1