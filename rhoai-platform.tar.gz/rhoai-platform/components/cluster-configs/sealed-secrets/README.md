# Sealed Secrets (kubeseal)

Deploys the Bitnami Sealed Secrets controller for encrypting Kubernetes Secrets at rest in Git.

## Important: Namespace

This deployment targets the `sealed-secrets` namespace — **not** the upstream default of `kube-system`. All namespace references in the controller manifest (`base/v0.38.4-controller.yaml`) have been updated accordingly.

When upgrading the controller version, do **not** drop in the upstream manifest as-is. You must replace all `namespace: kube-system` occurrences with `namespace: sealed-secrets` so that:

- The ServiceAccount, Deployment, Services, Roles, and RoleBindings land in the correct namespace.
- The ClusterRoleBinding and RoleBinding subjects point to the ServiceAccount in `sealed-secrets`.

## Usage

```
oc apply -k components/cluster-configs/sealed-secrets/overlays/default
```

As part of a different overlay in your own GitOps repo:

```yaml
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
resources:
  - components/cluster-configs/sealed-secrets/overlays/default
```

## Creating a SealedSecret

Use the helper script at `scripts/seal-secret.sh` which pre-configures the correct controller name and namespace:

```bash
# From an existing Secret YAML
seal-secret.sh -f my-secret.yaml -o my-sealed-secret.yaml

# From literal values
seal-secret.sh -n my-app -s db-credentials \
  --from-literal username=admin \
  --from-literal password=s3cr3t
```

Run `scripts/seal-secret.sh --help` for all options.

## Upgrading

1. Download the new controller manifest from the [Sealed Secrets releases](https://github.com/bitnami-labs/sealed-secrets/releases).
2. Replace `base/v<old>-controller.yaml` with the new file (rename to match the version).
3. Replace all `namespace: kube-system` with `namespace: sealed-secrets` in the new manifest.
4. Update the resource reference in `base/kustomization.yaml` to point to the new filename.
