helm repo add nvidia https://helm.ngc.nvidia.com/nvidia

helm install network-operator nvidia/network-operator \
  --namespace nvidia-network-operator \
  --create-namespace --version 25.1.0

# Apply RDMA + macvlan configuration
kubectl apply -f nvidia-network-operator-config.yaml

# Create macvlan network attachments
kubectl apply -f ib-network-attachments.yaml

# Deploy test pods
kubectl apply -f ib-test-pod.yaml


###### For RKE2 need to disable multus and use this #############
# Install the RKE2-compatible thick mode Multus
kubectl apply -f https://raw.githubusercontent.com/k8snetworkplumbingwg/multus-cni/master/deployments/multus-daemonset-thick.yml

# Configure for GPU nodes
kubectl patch daemonset kube-multus-ds -n kube-system --type='merge' -p='{
  "spec": {
    "template": {
      "spec": {
        "tolerations": [
          {"key": "target", "operator": "Exists"},
          {"key": "tenant", "operator": "Exists"}
        ],
        "nodeSelector": {
          "kubernetes.oip/gpu-present": "true"
        }
      }
    }
  }
}'

# Verify it's running
kubectl get pods -n kube-system -l app=multus