#!/bin/bash
set -e

# === Configuration ===
SRC_DIR="."                                    # Directory containing ai-* files
BACKUP_DIR="./backup_$(date +%d%m%Y_%H%M%S)"  # Timestamped backup folder
KEYWORD="roce_macs:"                          # YAML key to reverse

# === Step 1: Backup all ai-* files ===
mkdir -p "$BACKUP_DIR"
echo "[INFO] Backing up ai-* files to $BACKUP_DIR ..."
cp ai-* "$BACKUP_DIR"/
echo "[INFO] Backup completed."

# === Step 2: Reverse roce_macs entries in each ai-* YAML ===
for file in ai-*; do
  echo "[INFO] Processing $file ..."
  
  # Use awk to detect the roce_macs block and reverse its list
  awk -v key="$KEYWORD" '
  BEGIN {in_block=0; n=0}
  {
    if ($0 ~ key) {
      print $0
      in_block=1
      n=0
      next
    }

    if (in_block && $0 ~ /^  - /) {
      macs[n++] = $0
      next
    }

    if (in_block && $0 !~ /^  - /) {
      for (i=n-1; i>=0; i--) print macs[i]
      in_block=0
    }

    if (!in_block || $0 !~ /^  - /)
      print $0
  }
  END {
    if (in_block) {
      for (i=n-1; i>=0; i--) print macs[i]
    }
  }' "$file" > "${file}.tmp" && mv "${file}.tmp" "$file"

  echo "[OK] Reversed roce_macs in $file"
done

echo "[DONE] All files updated successfully."
