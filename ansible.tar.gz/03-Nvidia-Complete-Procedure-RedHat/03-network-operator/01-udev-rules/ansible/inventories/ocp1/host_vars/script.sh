#!/bin/bash
input_file="test"
output_file="tiger-dev-gpu-20.yaml"
macs=($(grep -oE '([a-fA-F0-9]{2}:){5}[a-fA-F0-9]{2}' "$input_file"))
echo "roce_macs:" > "$output_file"
for i in {0..7}; do
  if [ $i -lt ${#macs[@]} ]; then
    echo "  - \"${macs[$i]}\"" >> "$output_file"
  else
    echo "  - \"\"" >> "$output_file"
  fi
done

